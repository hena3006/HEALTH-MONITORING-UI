package mc.assignment.group15;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.FrameLayout;

//package imported from http://www.android-graphview.org
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    Thread updateThread = null; //thread to update graph
    boolean runPressed = false; //variable to keep the thread running

    GraphView graph;
    LineGraphSeries<DataPoint> series;  //data points associated with graph
    ArrayList<DataPoint> history;   //remember data when stop pressed
    double lastXvalue = 0;  //latest data point on X axis

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Button runBtn = (Button) findViewById(R.id.RunBtn); //run button
        Button stopBtn = (Button) findViewById(R.id.StopBtn);   //stop button

        //when run button is clicked:
            //instantiate the graph and data-series, if not already instantiated.
            //start a (periodic) thread to update graph, if not already started, else return.
        runBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                if (graph == null) {
                    //instantiate graph
                    graph = new GraphView(v.getContext());
                    FrameLayout graphFrame = (FrameLayout) findViewById(R.id.graphFrame);

                    series = new LineGraphSeries<>();   //instantiate series of data points
                    history = new ArrayList<>();    //instantiate historical data array
                    history.add(new DataPoint(0, 0));

                    graph.addSeries(series);    //associate series with graph

                    //control amount of data (X-axis) shown on the screen
                    graph.getViewport().setXAxisBoundsManual(true);
                    graph.getViewport().setMinX(0);
                    graph.getViewport().setMaxX(9);

                    //add graph to its (frame) layout
                    graphFrame.addView(graph);

                }

                //ignore this click event if Run button was previously clicked.
                if (runPressed) return;

                //remember this click
                runPressed = true;

                //retrieve historical data from ArrayList into array
                DataPoint[] oldData = new DataPoint[history.size()];
                history.toArray(oldData);

                //feed array of historical data to the data series
                series.resetData(oldData);

                //define new thread for updating graph
                updateThread = new Thread(new Runnable() {
                    public void run() {
                        //thread runs until "runPressed" is reset by clicking the Stop button
                        while(runPressed) {
                            //update the graph data
                            updateData();

                            //sleep for 100 ms
                            try {
                                Thread.sleep(100);
                            } catch(InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });

                //start thread
                updateThread.start();

            }
        });

        //when Stop button is pressed,
            //reset the flag "runPressed", which will cause the thread to exit
            //reset the graph's data series with temporary (0,0) values
        stopBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                runPressed = false;

                //wait for the thread to exit, before making changes to the graph's data series
                try {
                    updateThread.join();
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }

                //reset graph's data series
                DataPoint[] resetArray = new DataPoint[1];
                resetArray[0] = new DataPoint(0, 0);
                series.resetData(resetArray);
            }
        });

    }

    private void updateData() {
        //this method appends a new data point to the graph's data series

        boolean scrollToEnd = false;

        //new point's coordinate on X-axis
        lastXvalue++;

        //scroll viewport to the last X value only on this condition...
        if (lastXvalue >= 9) scrollToEnd = true;

        //fetch new random value for data-point
        DataPoint newPoint = new DataPoint(lastXvalue, Math.random() * 3000);

        //remember this data point
        history.add(newPoint);

        //update graph's data series
        series.appendData(newPoint, scrollToEnd, 10);

    }

    @Override
    public void onDestroy() {

        //make sure that the thread exits before closing this activity
        if (updateThread != null) {
            runPressed = false;
            try {
                updateThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        super.onDestroy();
    }

}